<?php

require_once  XSTUDIOAPP_PATH  . "/includes/helpers/wordpress/categories.php";
require_once  XSTUDIOAPP_PATH  . "/includes/helpers/wordpress/post.php";
require_once  XSTUDIOAPP_PATH  . "/includes/helpers/wordpress/cart.php";
require_once  XSTUDIOAPP_PATH  . "/includes/helpers/wordpress/xsatools.php";