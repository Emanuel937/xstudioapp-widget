<?php

class XSATools{

    use Cart, Categories, Post;
}

$xwoo = new XSATools();
//$xwoo->get_cart_data();

