<?php

define('__WIDGET_NAMESPACE__'            , 'XstudioApp\\Widgets\\');                     // every widget is on this namespace
define('__WIDGET_PHP_DIR_PATTERN__'      , 'includes/widgets/*.php');                    // pattern used to find on widget file 
define('__WIDGET_JS_DIR_PATTERN__'       , 'build/assets/js/*.js');
define('__WIDGET_CSS_DIR_PATTERN__'      , 'build/assets/css/*.css');
define('__PLUGINS_FILE__'                   , 'xstudioapp-widget/xstudioapp-widget.php');