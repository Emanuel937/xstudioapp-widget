<?php

require_once  XSTUDIOAPP_PATH  . "/includes/variables/widgetVariables.php";