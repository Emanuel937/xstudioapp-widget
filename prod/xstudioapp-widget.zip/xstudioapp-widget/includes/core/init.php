<?php

require_once  XSTUDIOAPP_PATH  . "includes/core/XstudioAppRegisterWidget.php";
require_once  XSTUDIOAPP_PATH  . "includes/core/XStudioAppInit.php";

