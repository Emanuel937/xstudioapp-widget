<?php

require_once  XSTUDIOAPP_PATH  . "/includes/assets/css.php";
require_once  XSTUDIOAPP_PATH  . "/includes/assets/js.php";
require_once  XSTUDIOAPP_PATH  . "/includes/assets/fontawesome.php";
