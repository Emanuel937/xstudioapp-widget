<?php 


// ===========================================================
//                       INIT ALL CLASS 
//  ==========================================================

require_once  XSTUDIOAPP_PATH  . "includes/variables/init.php";
require_once  XSTUDIOAPP_PATH  . "includes/assets/init.php";
require_once  XSTUDIOAPP_PATH  . "includes/helpers/init.php";
require_once  XSTUDIOAPP_PATH  . "includes/core/init.php";
require_once  XSTUDIOAPP_PATH  . "includes/admin/init.php";
 