<?php
/**
 * Plugin Name: X-StudioApp Widget for Elementor
 * Description: X-StudioApp widget holds all Elementor Pro widgets and more.
 * Version: 1.0
 * Author: X-StudioApp
 * Text Domain: x-studioapp-widget
 */

if (!defined('ABSPATH')) exit;

define('XSTUDIOAPP_PATH', plugin_dir_path(__FILE__));
define('XSTUDIOAPP_URL',  plugin_dir_url(__FILE__));    

require_once XSTUDIOAPP_PATH . 'class/phpClass/error.php';                   // check if elementor is installed
require_once XSTUDIOAPP_PATH . 'includes/xstudioapp-register-widget.php';   // register class to add widget it is used on XstudioInit Class
require_once XSTUDIOAPP_PATH . 'includes/xfile.php';                 

// load clas that register js and cs file#
//require_once XSTUDIOAPP_PATH . 'class/phpClass/template.php';    // customer template manager, no nedd anymore
require_once XSTUDIOAPP_PATH . 'class/phpClass/menu.php';        // create menu and submenu
require_once XSTUDIOAPP_PATH . 'class/phpClass/XstudioInit.php';   // register class is handle on this file



/*
function xsa_render_elementor_template($type) {
    $option_name = "xsa_active_{$type}_template";
    $template_id = get_option($option_name);
    if (!$template_id) return false;

    $post = get_post($template_id);
    if (!$post || $post->post_status !== 'publish') return false;

    if (!class_exists('\Elementor\Plugin')) return false;

    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($template_id);
    return true;
}

// Pour remplacer le header classique
add_action('get_header', function() {
    if (xsa_render_elementor_template('header')) {
        // Supprime la sortie du header classique
        ob_start();
        add_action('get_header', function() {
            ob_clean();
        }, 1);
    }
});

// Pour remplacer le footer classique
add_action('get_footer', function() {
    if (xsa_render_elementor_template('footer')) {
        // Supprime la sortie du footer classique
        ob_start();
        add_action('get_footer', function() {
            ob_clean();
        }, 1);
    }
});



// Pour remplacer le contenu "single" ou autre template (ex: single post, page, archive...)
add_filter('template_include', function($template) {
    $type = 'single'; // ici tu peux gérer selon contexte ou autre paramètre dynamique

    $template_id = get_option("xsa_active_{$type}_template");
    if (!$template_id) return $template;

    $post = get_post($template_id);
    if (!$post || $post->post_status !== 'publish') return $template;

    if (!class_exists('\Elementor\Plugin')) return $template;

    // Charger le template Elementor et empêcher le template WP classique de s'afficher
    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($template_id);

    // Retourne false pour annuler le template WP classique
    return false;
});
*/


/*
function xstudioapp_enqueue_custom_styles() {
    wp_enqueue_style(
        'elementor-icons-fa',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css',
        [],
        null
    );
}
add_action('wp_enqueue_scripts', 'xstudioapp_enqueue_custom_styles');
*/


function xstudioapp_enqueue_admin_icons($hook) {
    wp_enqueue_style(
        'elementor-icons-fa-admin',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css',
        [],
        null
    );
}
add_action('admin_enqueue_scripts', 'xstudioapp_enqueue_admin_icons');
add_action('elementor/frontend/after_register_styles', function() {
    // Charge manuellement la feuille de style FA 5/6
    wp_enqueue_style(
        'xstudioapp-fa',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css',
        [],
        null
    );
});

