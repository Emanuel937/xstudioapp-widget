<?php 

class ErrorMessage{
    
    static public function showError()
    {

        if (!did_action('elementor/loaded')) {
    
            add_action('admin_notices', function () {
                echo "<div class='notice notice-error'><p><strong>X-StudioApp Widget</strong> requires <a href='https://wordpress.org/plugins/elementor/' target='_blank'>Elementor</a> to be installed and activated.</p></div>";
        
            });

            exit;
        }
    }
}

ErrorMessage::showError();